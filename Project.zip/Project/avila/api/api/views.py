from django.http import HttpResponse
from django.shortcuts import render
import joblib

def home(request):
    return render(request, 'home.html')
    
def result(request):
    cls = joblib.load('/Users/sebastienyung/Documents/A4 ESILV/Python for data analysis/Project/avila/final_model.sav')
    
    lis=[]
    
    lis.append(request.GET['intercolumnar_distance'])
    lis.append(request.GET['upper_margin'])
    lis.append(request.GET['lower_margin'])
    lis.append(request.GET['exploitation'])
    lis.append(request.GET['row_number'])
    lis.append(request.GET['modular_ratio'])
    lis.append(request.GET['interlinear_spacing'])
    lis.append(request.GET['peak_number'])

    ans = cls.predict([lis])

    return render(request, 'result.html', {'ans':ans})
